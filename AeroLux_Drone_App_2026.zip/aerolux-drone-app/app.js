const drones=[
{id:"LX-2X",name:"Falcon",status:"flight",battery:78,payload:"25 kg",range:"30 km",speed:"120 km/h"},
{id:"LX-4H",name:"Hawk",status:"ready",battery:94,payload:"15 kg",range:"25 km",speed:"105 km/h"},
{id:"LX-8",name:"Octa",status:"service",battery:22,payload:"35 kg",range:"40 km",speed:"90 km/h"},
{id:"LX-1",name:"Swift",status:"ready",battery:88,payload:"10 kg",range:"20 km",speed:"110 km/h"},
{id:"LX-3P",name:"Pioneer",status:"ready",battery:72,payload:"18 kg",range:"28 km",speed:"100 km/h"},
{id:"LX-7M",name:"Manta",status:"flight",battery:61,payload:"20 kg",range:"35 km",speed:"115 km/h"}];

const $=s=>document.querySelector(s);
function showView(view){
 document.querySelectorAll('.view').forEach(v=>v.classList.remove('active-view'));
 const el=$('#'+view); if(el)el.classList.add('active-view');
 document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 const label=document.querySelector(`[data-view="${view}"]`);
 $('#pageLabel').textContent=label?label.textContent.trim():view;
 $('#sidebar').classList.remove('open');
 if(view==='analytics')setTimeout(drawAnalytics,30);
 if(view==='overview')setTimeout(drawPerformance,30);
 window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
$('#menuBtn').onclick=()=>$('#sidebar').classList.toggle('open');

function toast(msg){const t=$('#toastBox');t.textContent=msg;t.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove('show'),2300)}
function toggleNotifications(){const n=$('#notifications');n.style.display=n.style.display==='block'?'none':'block'}
function toggleTheme(){document.body.classList.toggle('light');localStorage.setItem('aerolux-theme',document.body.classList.contains('light')?'light':'dark')}
if(localStorage.getItem('aerolux-theme')==='light')document.body.classList.add('light');

function renderFleet(){
 const q=($('#fleetSearch')?.value||'').toLowerCase(), f=$('#fleetFilter')?.value||'all';
 const list=drones.filter(d=>(f==='all'||d.status===f)&&(`${d.id} ${d.name}`).toLowerCase().includes(q));
 $('#fleetGrid').innerHTML=list.map(d=>`
 <article class="drone-card">
  <div class="drone-visual"><span class="status ${d.status==='flight'?'live':d.status==='service'?'warning':'safe'} drone-tag">${d.status==='flight'?'IN FLIGHT':d.status==='service'?'MAINTENANCE':'READY'}</span>
   <div class="drone-svg"><div class="rotor r1"></div><div class="rotor r2"></div><div class="rotor r3"></div><div class="rotor r4"></div><div class="arm a1"></div><div class="arm a2"></div><div class="arm a3"></div><div class="arm a4"></div><div class="body"></div><div class="camera-eye"></div></div>
  </div>
  <div class="drone-body"><h3>${d.id} ${d.name}</h3><p>AI flight core • Autonomous navigation • Obstacle avoidance</p>
   <div class="specs"><div><span>Battery</span><b>${d.battery}%</b></div><div><span>Payload</span><b>${d.payload}</b></div><div><span>Range</span><b>${d.range}</b></div></div>
   <div class="card-actions"><button class="ghost" onclick="openDrone('${d.id}')">Details</button><button class="primary" onclick="startDrone('${d.id}')">${d.status==='flight'?'Track':'Assign'}</button></div>
  </div>
 </article>`).join('');
}
function renderFleetPreview(){
 $('#fleetPreview').innerHTML=drones.slice(0,4).map(d=>`<div class="fleet-row"><div class="drone-mini"></div><div><b>${d.id} ${d.name}</b><span>${d.status==='flight'?'Mission in progress':d.status==='service'?'Maintenance required':'Ready for mission'}</span></div><div><b>${d.battery}%</b><div class="battery"><i style="width:${d.battery}%"></i></div></div></div>`).join('');
}
function openDrone(id){const d=drones.find(x=>x.id===id);openModal(`<h2>${d.id} ${d.name}</h2><p>Aircraft profile and operational telemetry.</p><div class="telemetry-grid"><div><span>Status</span><b>${d.status.toUpperCase()}</b></div><div><span>Battery</span><b>${d.battery}%</b></div><div><span>Max payload</span><b>${d.payload}</b></div><div><span>Range</span><b>${d.range}</b></div><div><span>Top speed</span><b>${d.speed}</b></div><div><span>Firmware</span><b>v4.8.1</b></div></div><button class="primary full" style="margin-top:14px" onclick="toast('Aircraft diagnostics started');closeModal()">Run Diagnostics</button>`)}
function startDrone(id){toast(`${id} assigned to next available mission`)}
function openDroneModal(){openModal(`<h2>Add aircraft</h2><p>Register a new drone in the AeroLux fleet.</p><label>Drone ID<input placeholder="LX-9"></label><label>Model<input placeholder="Atlas Pro"></label><label>Payload capacity<select><option>10 kg</option><option>15 kg</option><option>25 kg</option><option>35 kg</option></select></label><button class="primary full" onclick="toast('Aircraft added to fleet');closeModal()">Add Aircraft</button>`)}

function openMission(){showView('missions');setTimeout(()=>$('#missionName')?.focus(),100)}
function validateMission(){
 const payload=Number($('#payloadInput').value);
 if(payload>25){toast('Payload exceeds selected aircraft limit');return}
 toast('Mission validated — route is safe and ready to dispatch');
}
function confirmEmergency(){if(confirm('Send emergency command to LX-2X Falcon?'))toast('Emergency procedure initiated — operator confirmation required')}

function openModal(html){$('#modalContent').innerHTML=html;$('#modal').style.display='grid'}
function closeModal(){$('#modal').style.display='none'}
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal()});

function drawChart(canvas,values,labels){
 const ctx=canvas.getContext('2d'),w=canvas.width=canvas.clientWidth*2,h=canvas.height=canvas.clientHeight*2;ctx.scale(2,2);
 const W=canvas.clientWidth,H=canvas.clientHeight;ctx.clearRect(0,0,W,H);
 ctx.strokeStyle='#23313d';ctx.lineWidth=1;
 for(let i=0;i<5;i++){const y=20+i*(H-45)/4;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
 const max=Math.max(...values)*1.15,min=0;const pts=values.map((v,i)=>({x:25+i*(W-45)/(values.length-1),y:H-25-(v-min)/(max-min)*(H-55)}));
 const grad=ctx.createLinearGradient(0,0,0,H);grad.addColorStop(0,'rgba(231,184,79,.28)');grad.addColorStop(1,'rgba(231,184,79,0)');
 ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.lineTo(pts.at(-1).x,H-25);ctx.lineTo(pts[0].x,H-25);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
 ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle='#e8b84e';ctx.lineWidth=2;ctx.stroke();
 pts.forEach((p,i)=>{ctx.fillStyle='#e8b84e';ctx.beginPath();ctx.arc(p.x,p.y,3,0,Math.PI*2);ctx.fill();ctx.fillStyle='#697681';ctx.font='9px Inter';ctx.fillText(labels[i],p.x-8,H-8)});
}
function drawPerformance(){const c=$('#performanceChart');if(c)drawChart(c,[42,58,48,72,64,88,79],['10','11','12','13','14','15','16'])}
function drawAnalytics(){const c=$('#analyticsChart');if(c)drawChart(c,[88,112,104,142,135,168,148,181,176,201],['Mon','Tue','Wed','Thu','Fri','Sat','Sun','Mon','Tue','Wed'])}

function toggleRecording(){toast('Recording started in demo mode')}
function capturePhoto(){toast('Photo captured to local media library')}
async function startCamera(){
 const v=$('#video');
 if(!navigator.mediaDevices?.getUserMedia){toast('Camera API is not available in this browser');return}
 try{const stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});v.srcObject=stream;v.style.display='block';$('.camera-placeholder').style.display='none';toast('Camera connected')}
 catch(e){toast('Camera permission was not granted')}
}
function exportReport(){
 const rows=[['Metric','Value'],['Mission success','99.2%'],['Fleet utilization','78%'],['Average flight time','22.8 min'],['Cost per delivery','$4.18']];
 const csv=rows.map(r=>r.join(',')).join('\n'),a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='aerolux-report.csv';a.click();toast('Report exported')}
function zoomMap(n){toast(n>0?'Map zoomed in':'Map zoomed out')}

let alt=118,speed=64,batt=78,eta=18;
setInterval(()=>{
 alt=Math.max(80,Math.min(150,alt+(Math.random()-.5)*5));
 speed=Math.max(40,Math.min(82,speed+(Math.random()-.5)*6));
 batt=Math.max(20,batt-.01);
 $('#altitude').textContent=Math.round(alt)+' m';$('#speed').textContent=Math.round(speed)+' km/h';$('#missionBattery').textContent=Math.round(batt)+'%';
 $('#tAlt').textContent=Math.round(alt)+' m';$('#tSpeed').textContent=Math.round(speed)+' km/h';$('#tBattery').textContent=Math.round(batt)+'%';
 $('#trackingDrone').style.left=(38+Math.sin(Date.now()/2500)*22)+'%';$('#trackingDrone').style.top=(52+Math.cos(Date.now()/3000)*17)+'%';
 $('#lastSync').textContent='Just now';
},1000);

renderFleetPreview();renderFleet();setTimeout(drawPerformance,100);
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
