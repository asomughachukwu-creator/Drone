# AeroLux Drone Operations App

A polished, responsive drone operations web app based on the uploaded AeroLux reference design.

## Run it
1. Open this folder in VS Code.
2. Open `index.html` with Live Server (recommended) or any local web server.
3. The app works as a front-end demo without a backend.

## Included
- Modern dark navy + gold command-center UI
- Responsive desktop/tablet/mobile layout
- Dashboard / command center
- Fleet management and search/filter
- Drone detail modal
- Mission planner with route validation demo
- Live tracking with simulated telemetry
- Return-to-home / hold / camera / emergency controls (demo commands)
- Browser camera preview through `getUserMedia`
- Media library UI
- Maintenance schedules
- Analytics charts
- CSV report export
- Safety and notification settings
- Dark/light theme
- PWA manifest + service worker

## Production integration
For real drone flight operations, connect the UI to a secure backend and the aircraft manufacturer's SDK/protocol (for example MAVLink/ArduPilot/PX4 or the specific manufacturer's cloud/SDK). Do not send real flight commands directly from an unauthenticated browser. Add authentication, role-based permissions, encrypted telemetry, audit logs, geofencing, weather/airspace services, remote-ID/compliance workflows, and a hardware-in-the-loop test environment before any live operation.

The map in this demo is intentionally simulated so it can run without a paid map API key.
